#include "queue.h"

class test {
public:
    //Test cases:
    void sizeTestCase();
    void isEmptyTestCase();
    void isFullTestCase();
    //The following have two test cases per function
    void dequeueTest1();
    void dequeueTest2();
    void enqueueTest1();
    void enqueueTest2();
    void peekTest1();
    void peekTest2();
};